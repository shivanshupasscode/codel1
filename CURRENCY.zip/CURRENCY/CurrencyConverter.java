package CURRENCY;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class CurrencyConverter {

    public static void main(String[] args) {
        try {
            while (true) {
                String fromCurrency = getUserInput("Enter the currency to convert from (e.g., USD): ");
                String toCurrency = getUserInput("Enter the currency to convert to (e.g., EUR): ");
                double amount = getAmountToConvert();

                double conversionRate = getConversionRate(fromCurrency, toCurrency);
                double convertedAmount = amount * conversionRate;

                System.out.println(amount + " " + fromCurrency + " is equal to " + convertedAmount + " " + toCurrency);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String getUserInput(String message) throws IOException {
        System.out.print(message);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        return reader.readLine();
    }

    private static double getAmountToConvert() throws IOException {
        String amountStr = getUserInput("Enter the amount to convert: ");
        return Double.parseDouble(amountStr);
    }

    private static double getConversionRate(String fromCurrency, String toCurrency) throws IOException {
        String requestUrl = "b8dce3c1a846f891afc14867522097df" + fromCurrency;
        URL url = new URL(requestUrl);

        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        int responseCode = connection.getResponseCode();

        if (responseCode == 200) {
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                response.append(line);
            }
            in.close();

            String responseBody = response.toString();

            // Parse the response to extract the exchange rate directly
            String startTag = "\"" + toCurrency + "\":";
            int startIndex = responseBody.indexOf(startTag) + startTag.length();
            int endIndex = responseBody.indexOf(",", startIndex);
            String rateValue = responseBody.substring(startIndex, endIndex).trim();

            return Double.parseDouble(rateValue);
        } else {
            throw new IOException("Failed to retrieve exchange rates. Response code: " + responseCode);
        }
    }
}
